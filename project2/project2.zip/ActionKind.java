package Fresh;

enum ActionKind {
	ACTIVITY, ANIMATION
}
