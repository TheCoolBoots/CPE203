package project2_4_19;
enum ActionKind
{
   ACTIVITY,
   ANIMATION
}
