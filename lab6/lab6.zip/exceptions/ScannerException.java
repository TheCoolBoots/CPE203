package exceptions;

public class ScannerException extends Exception {
}
