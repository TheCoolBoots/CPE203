package exceptions;

public class InvalidCharacterException extends ScannerException {
}
