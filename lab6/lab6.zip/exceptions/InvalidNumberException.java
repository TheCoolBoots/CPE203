package exceptions;

public class InvalidNumberException extends ScannerException {
}
