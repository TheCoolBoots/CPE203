
public class CircleException extends RuntimeException{
	public CircleException(String message) {
		super(message);
	}
}
